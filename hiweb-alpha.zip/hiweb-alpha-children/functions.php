<?php


	require_once dirname( __DIR__ ) . '/hiweb-alpha/hiweb-core-3/hiweb-core-3.php';

	add_action( 'after_setup_theme', function(){

		///INCLUDE SCRIPT AND FILES RIGHT HIRE...

	} );