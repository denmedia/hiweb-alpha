<?php

	if(!defined('HW_MIGRATION_SIMPLE_DIR')) define('HW_MIGRATION_SIMPLE_DIR', dirname(dirname(__FILE__)));
	if(!defined('HW_MIGRATION_SIMPLE_PREFIX')) define('HW_MIGRATION_SIMPLE_PREFIX', 'hw_migration_simple');
	if(!defined('HW_MIGRATION_SIMPLE_AM_SHOWINMENU')) define('HW_MIGRATION_SIMPLE_AM_SHOWINMENU', 'tools.php');
	if(!defined('HW_MIGRATION_SIMPLE_AM_SLUG')) define('HW_MIGRATION_SIMPLE_AM_SLUG', 'hw_migration_simple');