var hiweb_minify_admin = {



    init: function(){
        //...
    },

    get_current_minify_templates: function(){
        //...
    },

    make_window_for_critical_css: function(){
        //...
    },



};

jQuery(document).ready(hiweb_minify_admin.init);