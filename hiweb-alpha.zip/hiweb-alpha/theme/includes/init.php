<?php
	/**
	 * Created by PhpStorm.
	 * User: denisivanin
	 * Date: 2019-01-20
	 * Time: 00:44
	 */

	require_once __DIR__ . '/includes.php';
	require_once __DIR__ . '/admin.php';
	require_once __DIR__ . '/frontend.php';
	require_once __DIR__ . '/hooks.php';