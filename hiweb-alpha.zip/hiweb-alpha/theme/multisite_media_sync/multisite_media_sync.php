<?php

	namespace theme;


	class multisite_media_sync{


		static private $init = false;

		static function init(){

			if(self::$init) return;
			self::$init = true;



		}


	}