<?php

	add_action( 'init', 'hiweb\\post_types::do_register_post_types' );