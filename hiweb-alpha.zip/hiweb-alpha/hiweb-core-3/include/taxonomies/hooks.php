<?php

	//Register Taxonomies
	add_action( 'init', 'hiweb\\taxonomies::do_register_taxonomies' );