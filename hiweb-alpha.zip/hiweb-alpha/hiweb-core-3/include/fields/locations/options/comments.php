<?php
	/**
	 * Created by PhpStorm.
	 * User: denisivanin
	 * Date: 2019-01-19
	 * Time: 13:17
	 */

	namespace hiweb\fields\locations\options;


	class comments extends options {



	}