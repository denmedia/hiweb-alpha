<?php global $hiweb_theme_module_hamburgers_link ?><a href="<?=$hiweb_theme_module_hamburgers_link?>" class="hamburger hamburger--squeeze">
	<div class="hamburger-box">
		<div class="hamburger-inner"></div>
	</div>
</a>