<?php if( \theme\html_layout\tags\body::$use_wp_footer ) wp_footer(); ?>
</body>