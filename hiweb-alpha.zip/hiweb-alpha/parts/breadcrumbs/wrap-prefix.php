<!--hiweb_theme/widgets/breadcrumbs-->
<nav aria-label="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList"><ol class="breadcrumb <?=\theme\breadcrumbs::$class?>">