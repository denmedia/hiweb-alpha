<?php

	the_post();
	get_header();
	///
?>
	<main><?php
	the_content();
?></main><?php
	///

	get_footer();